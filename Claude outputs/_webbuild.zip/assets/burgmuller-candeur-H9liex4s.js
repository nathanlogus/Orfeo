const t=`<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE score-partwise PUBLIC "-//Recordare//DTD MusicXML 4.0 Partwise//EN" "http://www.musicxml.org/dtds/partwise.dtd">
<!-- Transcribed from the public-domain Mutopia edition (after the Collection Litolff) and checked note for note against its MIDI file. No fingering. Both halves repeated, the second with first and second endings, as in the source. Tempo mark Allegro moderato as in the edition; the metronome value (quarter = 152) is the one in the Mutopia MIDI block, not printed in the edition. Dynamics, hairpins, words and slurs as printed in the Mutopia LilyPond file (25EF-01.ly, piece 202) and its PDF. -->
<score-partwise version="4.0">
<work><work-number>Op. 100, No. 1</work-number><work-title>La Candeur</work-title></work>
<identification>
<creator type="composer">Friedrich Burgmüller</creator>
<rights>Music: public domain. This encoding: dacapo project, released under the MIT licence.</rights>
<encoding><encoder>dacapo project</encoder><software>dacapo scripts/pieces/generate.py</software><encoding-date>2026-09-30</encoding-date></encoding>
<source>Collection Litolff (19th century), as typeset by Bas Wassink for the Mutopia Project (piece 202, public domain): https://www.mutopiaproject.org/cgibin/piece-info.cgi?id=202</source>
</identification>
<part-list><score-part id="P1"><part-name>Piano</part-name></score-part></part-list>
<part id="P1">
<measure number="1">
<attributes><divisions>4</divisions><key><fifths>0</fifths></key><time><beats>4</beats><beat-type>4</beat-type></time><staves>2</staves><clef number="1"><sign>G</sign><line>2</line></clef><clef number="2"><sign>F</sign><line>4</line></clef></attributes>
<direction placement="above"><direction-type><words>Allegro moderato</words></direction-type><staff>1</staff><sound tempo="152"/></direction>
<direction placement="below"><direction-type><dynamics><p/></dynamics></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>G</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam><notations><slur type="start" number="1"/></notations></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam><notations><slur type="stop" number="1"/></notations></note>
<note><pitch><step>G</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam><notations><slur type="start" number="1"/></notations></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam><notations><slur type="stop" number="1"/></notations></note>
<backup><duration>16</duration></backup>
<direction placement="above"><direction-type><words font-style="italic">dolce</words></direction-type><voice>5</voice><staff>2</staff></direction>
<note><pitch><step>C</step><octave>3</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
<note><chord/><pitch><step>E</step><octave>3</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
<note><chord/><pitch><step>G</step><octave>3</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
</measure>
<measure number="2">
<direction placement="below"><direction-type><wedge type="diminuendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>C</step><octave>6</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam><notations><slur type="start" number="1"/></notations></note>
<note><pitch><step>A</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>G</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam><notations><slur type="stop" number="1"/></notations></note>
<note><pitch><step>C</step><octave>6</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam><notations><slur type="start" number="1"/></notations></note>
<note><pitch><step>A</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>G</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam><notations><slur type="stop" number="1"/></notations></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>3</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
<note><chord/><pitch><step>F</step><octave>3</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
<note><chord/><pitch><step>A</step><octave>3</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
</measure>
<measure number="3">
<note><pitch><step>G</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam><notations><slur type="start" number="1"/></notations></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam><notations><slur type="stop" number="1"/></notations></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>3</octave></pitch><duration>16</duration><tie type="start"/><voice>5</voice><type>whole</type><staff>2</staff><notations><tied type="start"/></notations></note>
<note><chord/><pitch><step>E</step><octave>3</octave></pitch><duration>16</duration><tie type="start"/><voice>5</voice><type>whole</type><staff>2</staff><notations><tied type="start"/></notations></note>
<note><chord/><pitch><step>G</step><octave>3</octave></pitch><duration>16</duration><tie type="start"/><voice>5</voice><type>whole</type><staff>2</staff><notations><tied type="start"/></notations></note>
</measure>
<measure number="4">
<note><pitch><step>G</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam><notations><slur type="start" number="1"/></notations></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam><notations><slur type="stop" number="1"/></notations></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>3</octave></pitch><duration>16</duration><tie type="stop"/><voice>5</voice><type>whole</type><staff>2</staff><notations><tied type="stop"/></notations></note>
<note><chord/><pitch><step>E</step><octave>3</octave></pitch><duration>16</duration><tie type="stop"/><voice>5</voice><type>whole</type><staff>2</staff><notations><tied type="stop"/></notations></note>
<note><chord/><pitch><step>G</step><octave>3</octave></pitch><duration>16</duration><tie type="stop"/><voice>5</voice><type>whole</type><staff>2</staff><notations><tied type="stop"/></notations></note>
</measure>
<measure number="5">
<direction placement="below"><direction-type><words font-style="italic">cresc.</words></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>G</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam><notations><slur type="start" number="1"/></notations></note>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam><notations><slur type="stop" number="1"/></notations></note>
<note><pitch><step>G</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam><notations><slur type="start" number="1"/></notations></note>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam><notations><slur type="stop" number="1"/></notations></note>
<backup><duration>16</duration></backup>
<note><pitch><step>B</step><octave>2</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
<note><chord/><pitch><step>F</step><octave>3</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
<note><chord/><pitch><step>G</step><octave>3</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
</measure>
<measure number="6">
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam><notations><slur type="start" number="1"/></notations></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam><notations><slur type="stop" number="1"/></notations></note>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam><notations><slur type="start" number="1"/></notations></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam><notations><slur type="stop" number="1"/></notations></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>3</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
<note><chord/><pitch><step>E</step><octave>3</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
<note><chord/><pitch><step>G</step><octave>3</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
</measure>
<measure number="7">
<direction placement="below"><direction-type><wedge type="crescendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam><notations><slur type="start" number="1"/></notations></note>
<note><pitch><step>A</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>A</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<backup><duration>16</duration></backup>
<note><pitch><step>D</step><octave>3</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
<note><chord/><pitch><step>F</step><alter>1</alter><octave>3</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><accidental>sharp</accidental><staff>2</staff></note>
<note><chord/><pitch><step>C</step><octave>4</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
</measure>
<measure number="8">
<note><pitch><step>G</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<note><pitch><step>G</step><octave>5</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff><notations><slur type="stop" number="1"/></notations></note>
<note><rest/><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<backup><duration>16</duration></backup>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>12</duration><voice>5</voice><type>half</type><dot/><staff>2</staff></note>
<note><chord/><pitch><step>B</step><octave>3</octave></pitch><duration>12</duration><voice>5</voice><type>half</type><dot/><staff>2</staff></note>
<note><rest/><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<barline location="right"><bar-style>light-heavy</bar-style><repeat direction="backward"/></barline>
</measure>
<measure number="9">
<barline location="left"><bar-style>heavy-light</bar-style><repeat direction="forward"/></barline>
<direction placement="below"><direction-type><dynamics><p/></dynamics></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam><notations><slur type="start" number="1"/></notations></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<backup><duration>16</duration></backup>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam><notations><slur type="start" number="3"/></notations></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam><notations><slur type="stop" number="3"/></notations></note>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam><notations><slur type="start" number="3"/></notations></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam><notations><slur type="stop" number="3"/></notations></note>
</measure>
<measure number="10">
<note><pitch><step>C</step><octave>5</octave></pitch><duration>16</duration><voice>1</voice><type>whole</type><staff>1</staff><notations><slur type="stop" number="1"/><slur type="start" number="1"/></notations></note>
<note><chord/><pitch><step>E</step><octave>5</octave></pitch><duration>16</duration><voice>1</voice><type>whole</type><staff>1</staff></note>
<backup><duration>16</duration></backup>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam><notations><slur type="start" number="3"/></notations></note>
<note><pitch><step>A</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam></note>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>E</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam><notations><slur type="stop" number="3"/></notations></note>
</measure>
<measure number="11">
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<backup><duration>16</duration></backup>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam><notations><slur type="start" number="3"/></notations></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam><notations><slur type="stop" number="3"/></notations></note>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam><notations><slur type="start" number="3"/></notations></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam><notations><slur type="stop" number="3"/></notations></note>
</measure>
<measure number="12">
<direction placement="below"><direction-type><wedge type="crescendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>16</duration><voice>1</voice><type>whole</type><staff>1</staff><notations><slur type="stop" number="1"/></notations></note>
<note><chord/><pitch><step>E</step><octave>5</octave></pitch><duration>16</duration><voice>1</voice><type>whole</type><staff>1</staff></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<backup><duration>16</duration></backup>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam><notations><slur type="start" number="3"/></notations></note>
<note><pitch><step>A</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam></note>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>E</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam><notations><slur type="stop" number="3"/></notations></note>
</measure>
<measure number="13">
<direction placement="below"><direction-type><wedge type="diminuendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>G</step><octave>5</octave></pitch><duration>8</duration><voice>1</voice><type>half</type><stem>up</stem><staff>1</staff></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<direction placement="below"><direction-type><wedge type="diminuendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>F</step><alter>1</alter><octave>5</octave></pitch><duration>8</duration><voice>1</voice><type>half</type><accidental>sharp</accidental><stem>up</stem><staff>1</staff></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<backup><duration>16</duration></backup>
<note><rest/><duration>2</duration><voice>2</voice><type>eighth</type><staff>1</staff></note>
<note><pitch><step>E</step><alter>-1</alter><octave>5</octave></pitch><duration>2</duration><voice>2</voice><type>eighth</type><accidental>flat</accidental><stem>down</stem><staff>1</staff><beam number="1">begin</beam><notations><slur type="start" number="2"/></notations></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>2</voice><type>eighth</type><stem>down</stem><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>2</voice><type>eighth</type><stem>down</stem><staff>1</staff><beam number="1">end</beam><notations><slur type="stop" number="2"/></notations></note>
<note><rest/><duration>2</duration><voice>2</voice><type>eighth</type><staff>1</staff></note>
<note><pitch><step>E</step><alter>-1</alter><octave>5</octave></pitch><duration>2</duration><voice>2</voice><type>eighth</type><stem>down</stem><staff>1</staff><beam number="1">begin</beam><notations><slur type="start" number="2"/></notations></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>2</voice><type>eighth</type><stem>down</stem><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>2</voice><type>eighth</type><stem>down</stem><staff>1</staff><beam number="1">end</beam><notations><slur type="stop" number="2"/></notations></note>
<backup><duration>16</duration></backup>
<note><pitch><step>A</step><octave>3</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<note><pitch><step>A</step><octave>3</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<note><chord/><pitch><step>C</step><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
</measure>
<measure number="14">
<direction placement="below"><direction-type><dynamics><sf/></dynamics></direction-type><voice>1</voice><staff>1</staff></direction>
<direction placement="below"><direction-type><wedge type="diminuendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>A</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam><notations><slur type="start" number="1"/></notations></note>
<note><pitch><step>G</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam><notations><slur type="stop" number="1"/></notations></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam><notations><slur type="start" number="1"/></notations></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam><notations><slur type="stop" number="1"/><slur type="start" number="1"/></notations></note>
<note><pitch><step>G</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>A</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<backup><duration>16</duration></backup>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
<note><chord/><pitch><step>C</step><octave>4</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
<note><chord/><pitch><step>E</step><octave>4</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
</measure>
<measure number="15">
<direction placement="below"><direction-type><dynamics><p/></dynamics></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<direction placement="below"><direction-type><words font-style="italic">dolce e poco rit.</words></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam><notations><slur type="stop" number="1"/><slur type="start" number="1"/></notations></note>
<note><pitch><step>G</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>A</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<backup><duration>16</duration></backup>
<attributes><clef number="2"><sign>G</sign><line>2</line></clef></attributes>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<note><chord/><pitch><step>F</step><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<note><chord/><pitch><step>F</step><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
</measure>
<measure number="16">
<barline location="left"><ending number="1" type="start">1.</ending></barline>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>12</duration><voice>1</voice><type>half</type><dot/><staff>1</staff><notations><slur type="stop" number="1"/></notations></note>
<note><rest/><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam><notations><slur type="start" number="3"/></notations></note>
<note><pitch><step>E</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>F</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>G</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff><notations><slur type="stop" number="3"/></notations></note>
<note><rest/><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<barline location="right"><bar-style>light-heavy</bar-style><ending number="1" type="stop"/><repeat direction="backward"/></barline>
</measure>
<measure number="17">
<barline location="left"><ending number="2" type="start">2.</ending></barline>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam><notations><slur type="start" number="1"/></notations></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>G</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<note><chord/><pitch><step>E</step><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<note><rest/><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<barline location="right"><ending number="2" type="discontinue"/></barline>
</measure>
<measure number="18">
<direction placement="below"><direction-type><wedge type="diminuendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<direction placement="below"><direction-type><wedge type="diminuendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<note><chord/><pitch><step>F</step><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<note><chord/><pitch><step>A</step><alter>-1</alter><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><accidental>flat</accidental><staff>2</staff></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<note><chord/><pitch><step>F</step><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<note><chord/><pitch><step>A</step><alter>-1</alter><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
</measure>
<measure number="19">
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam><notations><slur type="stop" number="1"/><slur type="start" number="1"/></notations></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>G</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
<note><chord/><pitch><step>E</step><octave>4</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
<note><chord/><pitch><step>G</step><octave>4</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff></note>
</measure>
<measure number="20">
<direction placement="below"><direction-type><wedge type="diminuendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<direction placement="below"><direction-type><wedge type="diminuendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>F</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">begin</beam></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">continue</beam></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>2</duration><voice>1</voice><type>eighth</type><staff>1</staff><beam number="1">end</beam></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<note><chord/><pitch><step>F</step><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<note><chord/><pitch><step>A</step><alter>-1</alter><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><accidental>flat</accidental><staff>2</staff></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<note><chord/><pitch><step>F</step><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
<note><chord/><pitch><step>A</step><alter>-1</alter><octave>4</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff></note>
</measure>
<measure number="21">
<note><pitch><step>C</step><octave>5</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff><notations><slur type="stop" number="1"/></notations></note>
<note><rest/><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<direction placement="below"><direction-type><dynamics><p/></dynamics></direction-type><voice>1</voice><staff>1</staff></direction>
<note><rest/><duration>8</duration><voice>1</voice><type>half</type><staff>1</staff></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><chord/><pitch><step>E</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><chord/><pitch><step>G</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><rest/><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<attributes><clef number="2"><sign>F</sign><line>4</line></clef></attributes>
<note><pitch><step>C</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam><notations><slur type="start" number="3"/></notations></note>
<note><pitch><step>E</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>F</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam></note>
</measure>
<measure number="22">
<direction placement="below"><direction-type><words font-style="italic">dim. e poco rit.</words></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>G</step><octave>4</octave></pitch><duration>8</duration><voice>1</voice><type>half</type><staff>1</staff></note>
<note><chord/><pitch><step>C</step><octave>5</octave></pitch><duration>8</duration><voice>1</voice><type>half</type><staff>1</staff></note>
<note><chord/><pitch><step>E</step><octave>5</octave></pitch><duration>8</duration><voice>1</voice><type>half</type><staff>1</staff></note>
<note><rest/><duration>8</duration><voice>1</voice><type>half</type><staff>1</staff></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>3</octave></pitch><duration>8</duration><voice>5</voice><type>half</type><staff>2</staff><notations><slur type="stop" number="3"/></notations></note>
<note><pitch><step>C</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam><notations><slur type="start" number="3"/></notations></note>
<note><pitch><step>E</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>F</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">continue</beam></note>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>2</duration><tie type="start"/><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam><notations><tied type="start"/></notations></note>
</measure>
<measure number="23">
<direction placement="below"><direction-type><dynamics><pp/></dynamics></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>E</step><octave>4</octave></pitch><duration>16</duration><voice>1</voice><type>whole</type><staff>1</staff></note>
<note><chord/><pitch><step>C</step><octave>5</octave></pitch><duration>16</duration><voice>1</voice><type>whole</type><staff>1</staff></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>3</octave></pitch><duration>16</duration><voice>5</voice><type>whole</type><staff>2</staff><notations><slur type="stop" number="3"/></notations></note>
<note><chord/><pitch><step>G</step><octave>3</octave></pitch><duration>16</duration><tie type="stop"/><voice>5</voice><type>whole</type><staff>2</staff><notations><tied type="stop"/></notations></note>
<barline location="right"><bar-style>light-heavy</bar-style></barline>
</measure>
</part>
</score-partwise>
`;export{t as default};
