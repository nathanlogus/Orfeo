const t=`<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE score-partwise PUBLIC "-//Recordare//DTD MusicXML 4.0 Partwise//EN" "http://www.musicxml.org/dtds/partwise.dtd">
<!-- Read from the scan of the Edition Peters print (revised by Adolf Ruthardt, c. 1895) and proofread blind by a second reader against the same scan (no MIDI file exists to check against). Fingering, slurs, hairpins and fermatas as printed in that edition. Both staves in the treble clef and no key signature, as printed (the tune is in G; no F occurs). The last bar is three beats long, completing the upbeat. The edition's tempo word; the metronome figure is ours. -->
<score-partwise version="4.0">
<work><work-number>Vorschule im Klavierspiel, Op. 101, No. 58</work-number><work-title>Abendlied</work-title></work>
<identification>
<creator type="composer">Ferdinand Beyer</creator>
<rights>Music: public domain. This encoding: dacapo project, released under the MIT licence.</rights>
<encoding><encoder>dacapo project</encoder><software>dacapo scripts/pieces/generate.py</software><encoding-date>2026-10-02</encoding-date></encoding>
<source>Vorschule im Klavierspiel, Op. 101, revised by Adolf Ruthardt (Leipzig: Edition Peters No. 2721, c. 1895, plate 8033), No. 58; scan on IMSLP (public domain): https://imslp.org/wiki/Vorschule_im_Klavierspiel,_Op.101_(Beyer,_Ferdinand)</source>
</identification>
<part-list><score-part id="P1"><part-name>Piano</part-name></score-part></part-list>
<part id="P1">
<measure number="0" implicit="yes">
<attributes><divisions>4</divisions><key><fifths>0</fifths></key><time><beats>4</beats><beat-type>4</beat-type></time><staves>2</staves><clef number="1"><sign>G</sign><line>2</line></clef><clef number="2"><sign>G</sign><line>2</line></clef></attributes>
<direction placement="above"><direction-type><words>Andante</words></direction-type><staff>1</staff><sound tempo="72"/></direction>
<direction placement="below"><direction-type><dynamics><p/></dynamics></direction-type><voice>1</voice><staff>1</staff></direction>
<direction placement="below"><direction-type><wedge type="crescendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>G</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff><notations><slur type="start" number="1"/><technical><fingering placement="above">1</fingering></technical></notations></note>
<backup><duration>4</duration></backup>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff><notations><slur type="start" number="3"/><technical><fingering placement="below">4</fingering></technical></notations></note>
</measure>
<measure number="1">
<note><pitch><step>A</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>G</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>E</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff><notations><technical><fingering placement="below">1</fingering></technical></notations></note>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff><notations><technical><fingering placement="below">2</fingering></technical></notations></note>
</measure>
<measure number="2">
<direction placement="below"><direction-type><wedge type="diminuendo" number="1"/></direction-type><offset>4</offset><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>A</step><octave>4</octave></pitch><duration>8</duration><voice>1</voice><type>half</type><staff>1</staff></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>G</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff><notations><slur type="stop" number="1"/></notations></note>
<direction placement="below"><direction-type><wedge type="crescendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff><notations><slur type="start" number="1"/><technical><fingering placement="above">2</fingering></technical></notations></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff><notations><technical><fingering placement="below">3</fingering></technical></notations></note>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam><notations><technical><fingering placement="below">1</fingering></technical></notations></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>6</duration><voice>5</voice><type>quarter</type><dot/><staff>2</staff><notations><slur type="stop" number="3"/></notations></note>
<note><pitch><step>A</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><notations><slur type="start" number="3"/></notations></note>
</measure>
<measure number="3">
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<backup><duration>16</duration></backup>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
</measure>
<measure number="4">
<note><pitch><step>C</step><octave>5</octave></pitch><duration>8</duration><voice>1</voice><type>half</type><staff>1</staff></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff><notations><technical><fingering placement="above">3</fingering></technical></notations></note>
<backup><duration>16</duration></backup>
<note><pitch><step>A</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam></note>
<note><pitch><step>A</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam></note>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>6</duration><voice>5</voice><type>quarter</type><dot/><staff>2</staff><notations><slur type="stop" number="3"/></notations></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><notations><slur type="start" number="3"/></notations></note>
</measure>
<measure number="5">
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<direction placement="below"><direction-type><wedge type="diminuendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<backup><duration>16</duration></backup>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>A</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam></note>
</measure>
<measure number="6">
<note><pitch><step>A</step><octave>4</octave></pitch><duration>12</duration><voice>1</voice><type>half</type><dot/><staff>1</staff><notations><slur type="stop" number="1"/></notations></note>
<direction placement="below"><direction-type><wedge type="crescendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>G</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff><notations><slur type="start" number="1"/></notations></note>
<backup><duration>16</duration></backup>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>6</duration><voice>5</voice><type>quarter</type><dot/><staff>2</staff></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff></note>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff><notations><slur type="stop" number="3"/></notations></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff><notations><slur type="start" number="3"/></notations></note>
</measure>
<measure number="7">
<note><pitch><step>A</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>G</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>E</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
</measure>
<measure number="8">
<direction placement="below"><direction-type><wedge type="diminuendo" number="1"/></direction-type><offset>4</offset><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>A</step><octave>4</octave></pitch><duration>8</duration><voice>1</voice><type>half</type><staff>1</staff></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>G</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff><notations><slur type="stop" number="1"/></notations></note>
<direction placement="below"><direction-type><wedge type="crescendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff><notations><slur type="start" number="1"/><technical><fingering placement="above">2</fingering></technical></notations></note>
<backup><duration>16</duration></backup>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam><notations><technical><fingering placement="below">1</fingering></technical></notations></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>6</duration><voice>5</voice><type>quarter</type><dot/><staff>2</staff><notations><slur type="stop" number="3"/></notations></note>
<note><pitch><step>A</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><notations><slur type="start" number="3"/></notations></note>
</measure>
<measure number="9">
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>E</step><octave>5</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>D</step><octave>5</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<backup><duration>16</duration></backup>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
</measure>
<measure number="10">
<note><pitch><step>C</step><octave>5</octave></pitch><duration>8</duration><voice>1</voice><type>half</type><staff>1</staff></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff><notations><technical><fingering placement="above">3</fingering></technical></notations></note>
<backup><duration>16</duration></backup>
<note><pitch><step>A</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam></note>
<note><pitch><step>A</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam></note>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>6</duration><voice>5</voice><type>quarter</type><dot/><staff>2</staff><notations><slur type="stop" number="3"/></notations></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><notations><slur type="start" number="3"/></notations></note>
</measure>
<measure number="11">
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<direction placement="below"><direction-type><wedge type="diminuendo" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>C</step><octave>5</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<backup><duration>16</duration></backup>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>A</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">begin</beam></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff><beam number="1">end</beam></note>
</measure>
<measure number="12">
<note><pitch><step>A</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>A</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<direction placement="below"><direction-type><wedge type="stop" number="1"/></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>G</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff><notations><slur type="stop" number="1"/><fermata type="upright"/></notations></note>
<backup><duration>12</duration></backup>
<note><pitch><step>D</step><octave>4</octave></pitch><duration>6</duration><voice>5</voice><type>quarter</type><dot/><staff>2</staff></note>
<note><pitch><step>C</step><octave>4</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff><notations><slur type="stop" number="3"/><fermata type="upright"/></notations></note>
<barline location="right"><bar-style>light-heavy</bar-style></barline>
</measure>
</part>
</score-partwise>
`;export{t as default};
