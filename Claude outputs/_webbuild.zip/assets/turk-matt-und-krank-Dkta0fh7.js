const t=`<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE score-partwise PUBLIC "-//Recordare//DTD MusicXML 4.0 Partwise//EN" "http://www.musicxml.org/dtds/partwise.dtd">
<!-- Read from the scan of the 1797 edition and proofread blind by a second reader against the same scan (no MIDI file exists to check against). Fingering and dynamics as printed in the 1797 edition. The last bar is two beats long, completing the upbeat. The edition's tempo words; the metronome figure is ours. -->
<score-partwise version="4.0">
<work><work-number>Sechzig Handstücke für angehende Klavierspieler, part 1, No. 9</work-number><work-title>Ich bin so matt und krank</work-title></work>
<identification>
<creator type="composer">Daniel Gottlob Türk</creator>
<rights>Music: public domain. This encoding: dacapo project, released under the MIT licence.</rights>
<encoding><encoder>dacapo project</encoder><software>dacapo scripts/pieces/generate.py</software><encoding-date>2026-10-02</encoding-date></encoding>
<source>Sechzig Handstücke für angehende Klavierspieler, Erster Theil, second edition (Leipzig and Halle: the author, 1797), No. 9; scan of the Bayerische Staatsbibliothek copy (public domain): https://www.digitale-sammlungen.de/en/view/bsb00086024?page=11</source>
</identification>
<part-list><score-part id="P1"><part-name>Piano</part-name></score-part></part-list>
<part id="P1">
<measure number="0" implicit="yes">
<attributes><divisions>4</divisions><key><fifths>1</fifths></key><time><beats>3</beats><beat-type>4</beat-type></time><staves>2</staves><clef number="1"><sign>G</sign><line>2</line></clef><clef number="2"><sign>F</sign><line>4</line></clef></attributes>
<direction placement="above"><direction-type><words>Largo molto e tenero</words></direction-type><staff>1</staff><sound tempo="56"/></direction>
<direction placement="below"><direction-type><dynamics><pp/></dynamics></direction-type><voice>1</voice><staff>1</staff></direction>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff><notations><technical><fingering placement="above">5</fingering></technical></notations></note>
<backup><duration>4</duration></backup>
<note><rest/><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
</measure>
<measure number="1">
<note><pitch><step>E</step><octave>4</octave></pitch><duration>8</duration><voice>1</voice><type>half</type><staff>1</staff></note>
<note><pitch><step>B</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<backup><duration>12</duration></backup>
<note><rest/><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<direction placement="below"><direction-type><dynamics><pp/></dynamics></direction-type><voice>5</voice><staff>2</staff></direction>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff><notations><technical><fingering placement="below">1</fingering></technical></notations></note>
<note><rest/><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
</measure>
<measure number="2">
<note><pitch><step>D</step><alter>1</alter><octave>4</octave></pitch><duration>8</duration><voice>1</voice><type>half</type><accidental>sharp</accidental><staff>1</staff><notations><technical><fingering placement="above">2</fingering></technical></notations></note>
<note><pitch><step>D</step><alter>1</alter><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<backup><duration>12</duration></backup>
<note><rest/><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>F</step><alter>1</alter><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><rest/><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
</measure>
<measure number="3">
<note><pitch><step>E</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff><notations><technical><fingering placement="above">1</fingering></technical></notations></note>
<note><pitch><step>F</step><alter>1</alter><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>G</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<backup><duration>12</duration></backup>
<note><rest/><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff></note>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff></note>
<note><pitch><step>D</step><alter>1</alter><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><accidental>sharp</accidental><staff>2</staff></note>
<note><pitch><step>E</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
</measure>
<measure number="4">
<note><pitch><step>A</step><octave>4</octave></pitch><duration>8</duration><voice>1</voice><type>half</type><staff>1</staff></note>
<note><pitch><step>A</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<backup><duration>12</duration></backup>
<note><pitch><step>C</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff><notations><technical><fingering placement="below">1</fingering></technical></notations></note>
<note><pitch><step>F</step><alter>1</alter><octave>2</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><rest/><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
</measure>
<measure number="5">
<note><pitch><step>C</step><octave>5</octave></pitch><duration>8</duration><voice>1</voice><type>half</type><staff>1</staff></note>
<note><pitch><step>D</step><alter>1</alter><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><accidental>sharp</accidental><staff>1</staff></note>
<backup><duration>12</duration></backup>
<note><rest/><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>A</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff><notations><technical><fingering placement="below">2</fingering></technical></notations></note>
<note><rest/><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
</measure>
<measure number="6">
<note><pitch><step>B</step><octave>4</octave></pitch><duration>8</duration><voice>1</voice><type>half</type><staff>1</staff></note>
<note><pitch><step>E</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff><notations><technical><fingering placement="above">1</fingering></technical></notations></note>
<backup><duration>12</duration></backup>
<note><rest/><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>G</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><rest/><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
</measure>
<measure number="7">
<note><pitch><step>A</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>G</step><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<note><pitch><step>F</step><alter>1</alter><octave>4</octave></pitch><duration>4</duration><voice>1</voice><type>quarter</type><staff>1</staff></note>
<backup><duration>12</duration></backup>
<note><rest/><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff></note>
<note><pitch><step>F</step><alter>1</alter><octave>3</octave></pitch><duration>2</duration><voice>5</voice><type>eighth</type><staff>2</staff></note>
<note><pitch><step>B</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>B</step><octave>2</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
</measure>
<measure number="8">
<note><pitch><step>E</step><octave>4</octave></pitch><duration>8</duration><voice>1</voice><type>half</type><staff>1</staff></note>
<backup><duration>8</duration></backup>
<note><pitch><step>E</step><octave>3</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<note><pitch><step>E</step><octave>2</octave></pitch><duration>4</duration><voice>5</voice><type>quarter</type><staff>2</staff></note>
<barline location="right"><bar-style>light-heavy</bar-style></barline>
</measure>
</part>
</score-partwise>
`;export{t as default};
